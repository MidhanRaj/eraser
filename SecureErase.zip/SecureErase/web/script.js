let selectedPaths = [];

function loadFiles() {
    let path = document.getElementById("path").value;
    if (!path) {
        alert("Please enter a path.");
        return;
    }
    document.getElementById("file-list").innerHTML = "Loading...";
    window.pywebview.api.list_files(path).then(files => {
        let html = "<ul>";
        files.forEach(file => {
            html += `<li>
                        <input type="checkbox" value="${file.path}">
                        ${file.is_dir ? "[DIR]" : "[FILE]"} ${file.name}
                     </li>`;
        });
        html += "</ul>";
        document.getElementById("file-list").innerHTML = html;
    });
}

function selectAll() {
    document.querySelectorAll('#file-list input[type="checkbox"]').forEach(cb => cb.checked = true);
}

function startWipe() {
    selectedPaths = [];
    document.querySelectorAll('#file-list input[type="checkbox"]:checked').forEach(cb => {
        selectedPaths.push(cb.value);
    });
    if (selectedPaths.length === 0) {
        alert("Please select at least one file/folder.");
        return;
    }
    document.getElementById("status").innerText = "Wiping...";
    window.pywebview.api.wipe(selectedPaths).then(response => {
        document.getElementById("status").innerText = response;
    });
}

function wipeFullOS() {
    let confirmText = document.getElementById("confirm-text").value;
    if (!confirmText) {
        alert("Please type CONFIRM to proceed.");
        return;
    }
    document.getElementById("status").innerText = "Performing full OS wipe...";
    window.pywebview.api.wipe_full_os(confirmText).then(response => {
        document.getElementById("status").innerText = response;
    });
}

