import os
import string
import webview
import shutil
import random

# Secure deletion for files
def secure_delete_file(path):
    try:
        if os.path.isfile(path):
            length = os.path.getsize(path)
            with open(path, "ba+", buffering=0) as f:
                f.seek(0)
                f.write(os.urandom(length))  # Overwrite with random data
            os.remove(path)
    except:
        pass

# Secure deletion for folders
def secure_delete_folder(path):
    for root, dirs, files in os.walk(path, topdown=False):
        for name in files:
            secure_delete_file(os.path.join(root, name))
        for name in dirs:
            try:
                os.rmdir(os.path.join(root, name))
            except:
                pass
    try:
        os.rmdir(path)
    except:
        pass

def get_drives():
    drives = []
    for drive in string.ascii_uppercase:
        if os.path.exists(f"{drive}:/"):
            drives.append(f"{drive}:/")
    return drives

def get_files_in_path(path):
    try:
        if os.path.exists(path):
            items = os.listdir(path)
            result = []
            for item in items:
                full_path = os.path.join(path, item)
                result.append({"name": item, "path": full_path, "is_dir": os.path.isdir(full_path)})
            return result
        else:
            return []
    except Exception as e:
        return [{"name": f"Error: {str(e)}", "path": "", "is_dir": False}]

def wipe_selected(paths):
    for path in paths:
        if os.path.isfile(path):
            secure_delete_file(path)
        elif os.path.isdir(path):
            secure_delete_folder(path)
    return "Selected items wiped."

def wipe_full_system():
    # This will target all drives except system reserved (C:/ by default)
    for drive in get_drives():
        if drive != "C:/":  # Skip OS by default for safety
            secure_delete_folder(drive)
    return "Full system wipe completed (excluding OS drive)."

# Expose API to JS
class API:
    def list_drives(self):
        return get_drives()

    def list_files(self, path):
        return get_files_in_path(path)

    def wipe(self, paths):
        return wipe_selected(paths)

    def wipe_full_os(self, confirm_text):
        if confirm_text.strip().lower() == "confirm":
            # Wipe everything including OS
            for drive in get_drives():
                secure_delete_folder(drive)
            return "⚠ OS and all data wiped successfully!"
        else:
            return "Confirmation failed. Type 'CONFIRM' to proceed."

if __name__ == '__main__':
    api = API()
    window = webview.create_window('Secure Wipe', 'web/index.html', js_api=api)
    webview.start()
